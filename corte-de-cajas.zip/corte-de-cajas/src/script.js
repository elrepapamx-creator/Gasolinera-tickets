let tickets = [];
let total = 0;

const totalEl = document.getElementById("total");
const contadorEl = document.getElementById("contador");
const inputArea = document.getElementById("inputArea");
const montoInput = document.getElementById("montoInput");
const historial = document.getElementById("historial");

document.getElementById("agregarBtn").onclick = () =>{
  inputArea.style.display="block";
  montoInput.focus();
}

document.getElementById("guardarMonto").onclick = agregarTicket;

function agregarTicket(){

  const monto = parseFloat(montoInput.value);

  if(!monto) return;

  tickets.push(monto);
  total += monto;

  actualizar();

  montoInput.value="";
  montoInput.focus();
}

document.getElementById("deshacerBtn").onclick = () =>{

  if(tickets.length===0) return;

  const ultimo = tickets.pop();
  total -= ultimo;

  actualizar();
}

document.getElementById("borrarBtn").onclick = () =>{

  tickets=[];
  total=0;

  actualizar();
}

document.getElementById("historialBtn").onclick = () =>{

  historial.innerHTML="";

  tickets.forEach((t,i)=>{

    const div=document.createElement("div");
    div.innerText=`${i+1} - $${t}`;

    historial.appendChild(div);

  });

}

function actualizar(){

  totalEl.innerText="$"+total.toFixed(2);
  contadorEl.innerText=tickets.length;

  totalEl.classList.remove("animar");
  void totalEl.offsetWidth;
  totalEl.classList.add("animar");

}

montoInput.addEventListener("keypress", function(e){

  if(e.key === "Enter"){
    agregarTicket();
  }

});
