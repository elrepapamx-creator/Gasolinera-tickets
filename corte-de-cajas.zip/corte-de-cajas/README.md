# Corte de cajas

A Pen created on CodePen.

Original URL: [https://codepen.io/Eduardo-Alonso-the-reactor/pen/XJjKydW](https://codepen.io/Eduardo-Alonso-the-reactor/pen/XJjKydW).

Esta es una aplicación sencilla para realizar cortes de caja en una gasolinera, tomando en cuenta tipos de gasolina, precios y litros vendidos, se busca darle practicidad para los empleados y ahorrarles tiempo